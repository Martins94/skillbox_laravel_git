<?php

namespace App\Http\Controllers;

use App\Models\Feedback;
use App\Models\Post;
use Illuminate\Http\Request;

class PostsController extends Controller
{
    public function index()
    {
        $posts = Post::latest()->get();

        return view('welcome', compact('posts'));
    }

    public function about()
    {
        return view('about');
    }

    public function contacts()
    {
        return view('contacts');
    }

    public function feedback()
    {
        $feedbacks = Feedback::latest()->get();

        return view('admin.feedbacks', compact('feedbacks'));
    }

    public function show(Post $post)
    {
        return view('posts.show', compact('post'));
    }

    public function create()
    {
        return view('posts.create');
    }

    public function store()
    {
        $this->validate(\request(), [
            'slug' => 'required|regex:/^[a-zA-Z0-9-_]+$/',
            'postTitle' => 'required|min:5|max:100',
            'shortDescr' => 'required|max:255',
            'description' => 'required'
        ]);

        Post::create([
            'slug' => request('slug'),
            'postTitle' => request('postTitle'),
            'shortDescr' => request('shortDescr'),
            'description' => request('description'),
            'published' => request()->boolean('published')
        ]);


        return redirect('/');
    }

    public function feedbackStore()
    {
        $this->validate(\request(), [
            'email' => 'required',
            'message' => 'required'
        ]);

        Feedback::create(\request()->all());

        return redirect('/admin/feedbacks');
    }
}
