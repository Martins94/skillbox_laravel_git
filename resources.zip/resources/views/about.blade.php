@extends('layout.master')

@section('title')
    О нас
@endsection

@section('content')
    <div class="col-md-8 blog-main mt-5">
        <h3 class="pb-3 mb-4 font-italic border-bottom">
            Cтраница о нас!
        </h3>
    </div><!-- /.blog-main -->
@endsection
