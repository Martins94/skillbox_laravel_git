@extends('layout.master')

@section('content')

    <div class="col-md-8 blog-main">
        <h3 class="pb-3 mb-4 mt-5 font-italic border-bottom">
            {{ $post->postTitle }}
        </h3>
        <p class="blog-post-meta">{{ $post->created_at->format('d.m.Y H:i:s') }}</p>

        <p>{{ $post->description }}</p>
        <hr>
        <a href="/">Ко всем статьям</a>
    </div><!-- /.blog-main -->
@endsection
