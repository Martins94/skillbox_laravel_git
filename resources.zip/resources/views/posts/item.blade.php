<div class="blog-post">
    <h2 class="blog-post-title"><a href="/posts/{{ $post->slug }}">{{ $post->postTitle }}</a> </h2>
    <p class="blog-post-meta">{{ $post->created_at->format('d.m.Y H:i:s') }}</p>

    <p>{{ $post->shortDescr }}</p>
    <hr>
</div>
