@extends('layout.master')

@section('title')
    Отзывы
@endsection

@section('content')

    <div class="col-md-8 blog-main mt-5">
        <h3 class="pb-3 mb-4 font-italic border-bottom">
            Отзывы
        </h3>
        @foreach($feedbacks as $feedback)
            @include('admin.item')
        @endforeach

    </div><!-- /.blog-main -->
@endsection
